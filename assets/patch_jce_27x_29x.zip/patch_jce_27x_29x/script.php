<?php
defined('_JEXEC') or die;

class patch_jce_27x_29xInstallerScript
{
    // Paths are identical across JCE 2.7.x, 2.8.x and 2.9.x — single package covers all branches.
    private $files = array(
        'components/com_jce/jce.php',
        'components/com_jce/controller.php',
        'components/com_jce/controller/editor.php',
        'components/com_jce/controller/plugin.php',
        'administrator/components/com_jce/controller/config.php',
        'administrator/components/com_jce/controller/cpanel.php',
        'administrator/components/com_jce/controller/profile.php',
        'administrator/components/com_jce/controller/profiles.php',
    );

    private function getCurrentVersion()
    {
        $manifest = JPATH_ADMINISTRATOR . '/manifests/packages/pkg_jce.xml';

        if (!is_file($manifest)) {
            return null;
        }

        if ($xml = @simplexml_load_file($manifest)) {
            return (string) $xml->version;
        }

        return null;
    }

    public function preflight($route, $_installer)
    {
        if ($route === 'uninstall' || $route === 'remove') {
            return true;
        }

        if (version_compare(PHP_VERSION, '5.3', 'lt')) {
            throw new RuntimeException('This patch requires PHP 5.3 or later. Installed version: ' . PHP_VERSION);
        }

        $version = $this->getCurrentVersion();

        if ($version === null) {
            throw new RuntimeException('JCE does not appear to be installed.');
        }

        if (version_compare($version, '2.7', 'lt')) {
            throw new RuntimeException('This patch requires JCE 2.7 or later. Installed version: ' . $version);
        }

        return true;
    }

    private function applyFix()
    {
        $store = JPATH_MANIFESTS . '/files/patch_jce_27x_29x';

        foreach ($this->files as $rel) {
            $src = $store . '/' . $rel;
            $dst = JPATH_ROOT . '/' . $rel;

            if (!is_file($src)) {
                continue;
            }

            $dir = dirname($dst);

            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }

            @copy($src, $dst);
        }
    }

    public function install($_adapter)
    {
        $this->applyFix();
        return true;
    }

    public function update($_adapter)
    {
        $this->applyFix();
        return true;
    }

    public function uninstall($_adapter)
    {
        // The patched files remain in place at their JCE paths.
        // Install a current JCE release to supersede this patch.
        return true;
    }
}
